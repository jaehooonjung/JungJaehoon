#include "Card.h"



Card::Card(int x, int y, CARDSHAPE Shape, CARDNUM Number) //ī�� ����
{
	m_eState = CARDSTATE_REAR;
	m_ix = x;
	m_iy = y;
	m_eShape = Shape;
	m_eNumber = Number;
	m_bGetState = false;
	m_bHideState = false;
}


void Card::ResetCard() //ī�� �ʱ�ȭ
{
	m_eState = CARDSTATE_REAR;
	m_bGetState = false;
	m_bHideState = false;
}

void Card::CardOpen() //ī�� ����
{
	m_eState = CARDSTATE_FRONT;
	CardDraw();
}


void Card::CardPositionSet(int x, int y) // ī�� ��ǥ����
{
	m_ix = x;
	m_iy = y;
}


void Card::EraseCard() //ī�� ȭ�鿡�� �����
{
	for (int y = m_iy; y < m_iy + CARDSIZE_HEIGHT; y++)
	{
		m_Interface.gotoxy(m_ix, y);
		for (int x = 0; x < CARDSIZE_WIDTH; x++)
			cout << "  ";
	}
}

void Card::DrawNum()// ī���ȣ �׸���
{
	if(m_eShape == CARDSHAPE_HEART || m_eShape == CARDSHAPE_DIAMOND)
		RED
	switch (m_eNumber)
	{
	case CARDNUM_2:
	case CARDNUM_3:
	case CARDNUM_4:
	case CARDNUM_5:
	case CARDNUM_6:
	case CARDNUM_7:
	case CARDNUM_8:
	case CARDNUM_9:
	case CARDNUM_10:
		cout << (int)m_eNumber;
		break;
	case CARDNUM_J:
		cout << "J";
		break;
	case CARDNUM_Q:
		cout << "Q";
		break;
	case CARDNUM_K:
		cout << "K";
		break;
	case CARDNUM_A:
		cout << "A";
		break;
	}
	ORIGINAL
}

void Card::DrawShape() //ī���� �׸���
{
	switch (m_eShape)
	{
	case CARDSHAPE_CLOVER:
		cout << "��";
		break;
	case CARDSHAPE_HEART:
		RED
		cout << "��";
		ORIGINAL
		break;
	case CARDSHAPE_DIAMOND:
		RED
			cout << "��";
		ORIGINAL
		break;
	case CARDSHAPE_SPADE:
		cout << "��";
		break;
	default:
		break;
	}
}

void Card::CardDraw() //ī��׸���
{
	for(int y = m_iy; y < m_iy +CARDSIZE_HEIGHT; y++)
	{
		m_Interface.gotoxy(m_ix,y);
		if(y == m_iy)
		{
			cout << "��";
			for(int x = 1; x < CARDSIZE_WIDTH - 1; x++)
				cout << "��";
			cout << "��";
		}
		else if(y == m_iy + CARDSIZE_HEIGHT-1)
		{
			cout << "��";
			for(int x = 1; x < CARDSIZE_WIDTH - 1; x++)
				cout << "��";
			cout << "��";
		}
		else
		{
			cout << "��";

				for(int x = 1; x < CARDSIZE_WIDTH - 1; x++)
				{
					if (m_eState == CARDSTATE_FRONT)
					{
						if (y == m_iy + 1 && x == 1)
						{
							DrawNum();
							if (m_eNumber != CARDNUM_10)
								cout << " ";
						}
						else if (y == m_iy + 2 && x == 1)
							DrawShape();
						else if(y == m_iy + (CARDSIZE_HEIGHT - 3) && x == CARDSIZE_WIDTH - 2)
							DrawShape();
						else if(y == m_iy + (CARDSIZE_HEIGHT - 2) && x == CARDSIZE_WIDTH - 2)
						{
							if (m_eNumber != CARDNUM_10)
								cout << " ";
							DrawNum();
						}
						else if((y == m_iy + CARDSIZE_HEIGHT / 2) && (x == CARDSIZE_WIDTH / 2))
							DrawShape();
						else
							cout << "  ";
					}
					else
					{
						cout << "��";
					}
				}
			cout << "��";
		}
	}
}

Card::~Card()
{
}
