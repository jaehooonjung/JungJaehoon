#include "Player.h"

int Player::PlayerCount = 1;

Player::Player(int x, int y, PLAYERTYPE Type, NAMEPOSITION Position) //�÷��̾� ������
{
	m_eNamePosition = Position;
	m_iMainBoxX = x;
	m_iMainBoxY = y;
	m_ePlayerType = Type;
	m_bPlayState = true;
	m_iCardCount = 0;
	if(m_ePlayerType == PLAYERTYPE_COMPUTER)
		m_strName = "Computer" + to_string(PlayerCount++);
	for (int i = 0; i < PLAYER_CARDMAX; i++)
		m_pMyCard[i] = NULL;
	m_iGold = 1000000;
	m_bAllPlayState = true;
}


int Player::BetGold(int Gold) //�÷��̾� ���� ������
{

	if (Gold > m_iGold)
	{
		Gold = m_iGold;
		m_iGold = 0;
	}
	else
		m_iGold -= Gold;
	return Gold;
}

void Player::EraseName() //�̸������
{
	string str = m_Interface.GetvoidString(m_strName + "(�ݾ�:" + to_string(m_iGold) + ")",1);
	switch (m_eNamePosition)
	{
	case NAMEPOSITION_UP:
		m_Interface.DrawMidText(str, m_iMainBoxX + PLAYERBOX_WIDTH, m_iMainBoxY - 1);
		break;
	case NAMEPOSITION_DOWN:
		m_Interface.DrawMidText(str, m_iMainBoxX + PLAYERBOX_WIDTH, m_iMainBoxY + PLAYERBOX_HEIGHT);
		break;
	}
}


void Player::Reset() //ī�帮��
{
	for (int i = 0; i < PLAYER_CARDMAX; i++)
		m_pMyCard[i] = NULL;
	m_iCardCount = 0;
}

void Player::NameDraw() //�̸� �׸���
{
	string str = m_strName + "(�ݾ�:" +  to_string(m_iGold) +")";
	switch (m_eNamePosition)
	{
	case NAMEPOSITION_UP:
		m_Interface.DrawMidText(str, m_iMainBoxX + PLAYERBOX_WIDTH, m_iMainBoxY - 1);
		break;
	case NAMEPOSITION_DOWN:
		m_Interface.DrawMidText(str, m_iMainBoxX + PLAYERBOX_WIDTH, m_iMainBoxY + PLAYERBOX_HEIGHT);
		break;
	}
}


void Player::SetCard(Card* card) //ī��ޱ�
{
	card->CardPositionSet(m_iMainBoxX+2 +(m_iCardCount*(CARDSIZE_WIDTH-3)), m_iMainBoxY+1);
	card->CardDraw();
	m_pMyCard[m_iCardCount++] = card;
}


void Player::AllOpen() //��üī�� ����
{
	for (int i = 0; i < m_iCardCount; i++)
	{
			m_pMyCard[i]->CardOpen();
	}
}

void Player::CardOpen() //������ ī�忭��
{
	m_pMyCard[m_iCardCount - 1]->CardOpen();
}

void Player::MainBoxDraw() //�ڽ��� ī�庸���� �׸���
{
	m_Interface.SmallBoxDraw(m_iMainBoxX, m_iMainBoxY, PLAYERBOX_WIDTH, PLAYERBOX_HEIGHT, m_bPlayState);
	NameDraw();
}


Player::~Player()
{
}
