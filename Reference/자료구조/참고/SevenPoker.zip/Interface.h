#pragma once
#include"Mecro.h"
#define UP 'w'
#define DOWN 's'
#define ENTER 13

class Interface
{
public:
	string GetvoidString(string str,int MulNum = 2);
	void DrawPoint(string str, int x, int y);
	void ErasePoint(int x, int y);
	int	MenuSelectCursor(int MenuLen, int AddCol, int x, int y);
	void DrawMidText(string str, int x, int y);
	void gotoxy(int x, int y);
	void DrawTitle(int Width, int Height);
	void BoxDraw(int Width, int Height);
	void SmallBoxDraw(int Startx, int Starty,int Width,int Height, bool State);
	Interface();
	~Interface();
};

