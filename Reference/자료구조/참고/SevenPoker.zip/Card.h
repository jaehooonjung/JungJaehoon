#pragma once
#include"Mecro.h"
#include"Interface.h"

enum CARDNUM
{
	CARDNUM_NULL,
	CARDNUM_START = 2,
	CARDNUM_2 = 2,
	CARDNUM_3,
	CARDNUM_4,
	CARDNUM_5,
	CARDNUM_6,
	CARDNUM_7,
	CARDNUM_8,
	CARDNUM_9,
	CARDNUM_10,
	CARDNUM_J,
	CARDNUM_Q,
	CARDNUM_K,
	CARDNUM_A,
	CARDNUM_END
};

enum CARDSHAPE
{
	CARDSHAPE_CLOVER,
	CARDSHAPE_HEART,
	CARDSHAPE_DIAMOND,
	CARDSHAPE_SPADE

};

enum CARDSIZE
{
	CARDSIZE_WIDTH = 7,
	CARDSIZE_HEIGHT = 10,
};

enum CARDSTATE
{
	CARDSTATE_FRONT,
	CARDSTATE_REAR
};

class Card
{
private:
	CARDSHAPE m_eShape;
	CARDNUM m_eNumber;
	Interface m_Interface;
	CARDSTATE m_eState;
	int m_ix;
	int m_iy;
	bool m_bGetState;
	bool m_bHideState;
public:
	inline CARDSTATE CardState() { return m_eState; }
	inline CARDNUM GetCardNum() { return m_eNumber; }
	inline CARDSHAPE GetCardShape() { return m_eShape; }
	inline void SetCardState(bool State) { m_bGetState = State; }
	inline bool GetCardState() { return m_bGetState; }
	inline bool GetCardHideState() { return m_bHideState; }
	inline void SetCardHideState(bool State) { m_bHideState = State; }
	void DrawShape();
	void DrawNum();
	void CardOpen();
	void EraseCard();
	void CardPositionSet(int x, int y);
	void CardDraw();
	void ResetCard();
	Card(int x,int y,CARDSHAPE Shape,CARDNUM Number);
	~Card();
};

