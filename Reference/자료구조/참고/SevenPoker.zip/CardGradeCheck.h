#pragma once
#include"CardManager.h"
#include"Mecro.h"

enum CARDGRADE
{
	CARDGRADE_NON,
	CARDGRADE_ONEPAIR,
	CARDGRADE_TWOPAIR,
	CARDGRADE_TRIPLE,
	CARDGRADE_STRAIGHT,
	CARDGRADE_BACKSTRAIGHT,
	CARDGRADE_MOUNTAIN,
	CARDGRADE_FLUSH,
	CARDGRADE_FULLHOUS,
	CARDGRADE_FOUR_OF_A_KIND,
	CARDGRADE_STRAIGHT_FLUSH,
	CARDGRADE_BACKSTRAIGHT_FLUSH,
	CARDGRADE_ROYAL_STRAIGHT_FLUSH
};

struct CardGrade
{
	int Playerindex;
	int m_iNextLevel = 0;
	CARDNUM m_eNumber;
	CARDGRADE m_eGrade = CARDGRADE_NON;
	CARDSHAPE m_eShape;
	int m_iStraightLevel = 0;
	int m_iFlushLevel = 0;	
	inline void operator = (CardGrade p)
	{
		m_eNumber = p.m_eNumber;
		m_eShape = p.m_eShape;
		m_iFlushLevel = p.m_iFlushLevel;
		m_iNextLevel = p.m_iNextLevel;
		m_iStraightLevel = p.m_iStraightLevel;
		m_eGrade = p.m_eGrade;
	}
};

struct CheckCardInfo
{
	CARDNUM m_eCardNum;
	CARDSHAPE m_eShape;
	bool m_bActiveState; 
	inline void operator = (CheckCardInfo p)
	{
		m_eCardNum = p.m_eCardNum;
		m_eShape = p.m_eShape;
		m_bActiveState = p.m_bActiveState;
	}
};

class CardGradeCheck
{
private:
	CheckCardInfo m_CheckCardInfo[PLAYER_CARDMAX];
	CardGrade m_Grade;
public:
	void Reset();
	void CopyCard(Card* Card[], bool PlayerState);
	CardGrade GradeCheck(Card* CheckCard[], CardManager* CardList,bool PlayerState,int CardCount);
	bool PairCheck(CardManager* CardList);
	void TwoPairCheck(CardManager* CardList);
	void StraightCehck(CardManager* CardList);
	void FlushCheck(CardManager* CardList);
	CardGradeCheck();
	~CardGradeCheck();
};

