#pragma once
#include"Card.h"
#include"Mecro.h"
class CardManager
{
private:
	Card* m_CardList[CARDMAX];
public:
	void CardReSet();
	inline Card** GetCardList() { return m_CardList; }
	void CardShuffle();
	void DrawCard();
	void ShapeSetCard(CARDSHAPE Shape, int& Count);
	Card* GetCard(bool State = false);
	int FindCardNum(CARDNUM num);
	int FindCardShape(CARDSHAPE Shape);
	CardManager();
	~CardManager();
};

