#pragma once
#include"Mecro.h"
#include"Interface.h"
#include"Card.h"

#define PLAYERBOX_WIDTH WIDTH * 0.27
#define PLAYERBOX_HEIGHT HEIGHT * 0.3

enum NAMEPOSITION
{
	NAMEPOSITION_UP,
	NAMEPOSITION_DOWN
};

enum PLAYERTYPE
{
	PLAYERTYPE_PLAYER,
	PLAYERTYPE_COMPUTER
};

class Player
{
private:
	Card* m_pMyCard[PLAYER_CARDMAX];
	NAMEPOSITION m_eNamePosition;
	PLAYERTYPE m_ePlayerType;
	Interface m_Interface;
	int m_iMainBoxX;
	int m_iMainBoxY;
	string m_strName;
	bool m_bPlayState;
	int m_iCardCount;
	int m_iGold;
	bool m_bAllPlayState;
public:
	static int PlayerCount;
	inline void ResetGold() { m_iGold = 1000000; }
	void Reset();
	void AllOpen();
	inline int GetCardCount() { return m_iCardCount; }
	int BetGold(int Gold);
	inline Card** GetCard() { return m_pMyCard; }
	void CardOpen();
	void SetCard(Card* card);
	inline int GetGold() { return m_iGold; }
	inline void SetGold(int gold) {	m_iGold += gold; }
	inline void SetName() { cin >> m_strName; }
	inline string GetName() { return m_strName; }
	void NameDraw();
	void EraseName();
	void MainBoxDraw();
	inline void SetAllPlayState(bool State) { m_bAllPlayState = State; }
	inline bool GetPlayerState() { return m_bPlayState; }
	inline void SetPlayerState(bool State)
	{
		if(m_bAllPlayState)
			m_bPlayState = State; 
	}
	Player(int x,int y,PLAYERTYPE Type,NAMEPOSITION Position);
	~Player();
};

