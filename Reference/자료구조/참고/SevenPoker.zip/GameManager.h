#pragma once
#include"Interface.h"
#include"Player.h"
#include"CardManager.h"
#include"CardGradeCheck.h"
#define PLAYER 0

class GameManager
{
private:
	Card* card;
	CardGradeCheck m_CardGradeCheck;
	CardManager m_CardManager;
	Player* m_arrPlayer[PLAYER_MAX];
	Interface m_Interface;
	int m_iWidth;
	int m_iHeight;
	CardGrade m_CardgradeList[6];
	int m_iGold;
	int m_iPanGold;
public:
	bool PanWindCheck(int index);
	void PlayerDelete();
	bool PlayerReset();
	void WinDraw(Player* player, CardGrade grade);
	void EnemyCardSort(int& Count,int index,bool State);
	void BetGoldDraw(int Gold);
	void GoldDraw();
	void SortGrade(int Max);
	void PushCard(int CardCount,int Startindex);
	void SetGame();
	void GamePlay(bool Auto = false);
	void GameMain();
	GameManager();
	~GameManager();
};

