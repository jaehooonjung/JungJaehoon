#include"GameManager.h"
#include"Card.h"

void main()
{
	srand(time(NULL));
	GameManager gameManager;
	gameManager.GameMain();
}