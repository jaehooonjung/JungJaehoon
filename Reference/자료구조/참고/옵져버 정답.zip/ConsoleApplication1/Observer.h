#pragma once
#include<string>
using namespace std;
class Observer
{
public:
	virtual void Update(string News, string Day) = 0;
	virtual void Show() = 0;
	Observer();
	~Observer();
};

