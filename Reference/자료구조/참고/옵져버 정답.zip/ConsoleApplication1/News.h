#pragma once
#include "Subject.h"
#include"Observer.h"
#include<vector>
#include<iostream>
#include<time.h>

using namespace std;
class News : public Subject
{
private:
	static News* m_hThis;
	vector<Observer*> ObserverList;
	string news;
	string Day;
public:
	virtual void NotifyObserver() ;
	virtual void AddObserver(Observer* input);
	void NewsUpdate();
	void ShowPerson();
	string currentDateTime();
	static News* GetInstans()
	{
		if (m_hThis == NULL)
			m_hThis = new News;
		return m_hThis;
	}
	News();
	~News();
};

