#include"Person.h"
#include"News.h"
#include<iostream>
#include<Windows.h>
using namespace std;


void menu()
{
	cout << "===Atents News===" << endl;
	cout << " 1. �������" << endl;
	cout << " 2. News ����" << endl;
	cout << " 3. News ������Ʈ" << endl;
	cout << " 4. News ��û" << endl;
	cout << " 5. ����" << endl;
	cout << "���� : " << endl;
}
void main()
{
	int choice;
	Person* tmp;
	while (1)
	{
		system("cls");
		menu();
		cin >> choice;
		switch (choice)
		{
		case 1:
			tmp = new Person;
			News::GetInstans()->AddObserver(tmp);
			break;
		case 2:
			News::GetInstans()->NotifyObserver();
			break;
		case 3:
			News::GetInstans()->NewsUpdate();
			break;
		case 4:
			News::GetInstans()->ShowPerson();
			break;
		case 5:
			delete 	News::GetInstans();
			return;
		default:
			cout << "�߸� �Է� �ϼ˽��ϴ�." << endl;
			break;
		}
		system("pause");
	}
}