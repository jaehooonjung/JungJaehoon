#pragma once
#include"Observer.h"
#include<iostream>
#include<string>
using namespace std;
class Person : public Observer
{
private:
	string name;
	string Day;
	string News;
public:
	virtual void Update(string News, string Day );
	virtual void Show();
	Person();
	~Person();
};

