#include "News.h"



News::News()
{
	this->news = "��ϵ� ������ ����";
}

News* News::m_hThis = NULL;

void News::NotifyObserver()
{
	for (auto iter = ObserverList.begin(); iter != ObserverList.end(); iter++)
	{
		(*iter)->Update(this->news,this->Day);
	}
}
void News::AddObserver(Observer* input)
{
	this->ObserverList.push_back(input);
}
void News::NewsUpdate()
{
	cout << "���ο� ��� ������ �Է� �Ͻÿ�" << endl;
	cin.ignore();
	getline(cin,news);
	this->Day = currentDateTime();
}

string News::currentDateTime() {
	time_t     now = time(0);
	struct tm  tstruct;
	char       buf[80];
	tstruct = *localtime(&now);
	strftime(buf, sizeof(buf), "%Y-%m-%d.%X", &tstruct);

	return buf;
}

void News::ShowPerson()
{
	for (auto iter = ObserverList.begin(); iter != ObserverList.end(); iter++)
	{
		(*iter)->Show();
	}
}
News::~News()
{
	for (auto iter = ObserverList.begin(); iter != ObserverList.end(); iter++)
	{
		delete (*iter);
	}
}
