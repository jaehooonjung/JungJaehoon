#pragma once
#include"IntManager.h"
class Test
{
public:
	Test();
	~Test();
};

