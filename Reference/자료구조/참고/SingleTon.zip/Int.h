#pragma once
#include<iostream>
using namespace std;

class Int
{
	int x;
	int y;
public:
	void Show();
	Int();

	~Int();
};

