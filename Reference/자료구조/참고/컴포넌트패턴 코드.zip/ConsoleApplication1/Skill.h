#pragma once
#include <iostream>
using namespace std;
class Skill
{
public:
	Skill();
	~Skill();
};

