#pragma once
#include<iostream>
using namespace std;
class Stat
{
public:
	Stat();
	~Stat();
};

