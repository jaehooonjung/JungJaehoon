#pragma once
#include<iostream>
using namespace std;
class Look
{
public:
	Look();
	~Look();
};

