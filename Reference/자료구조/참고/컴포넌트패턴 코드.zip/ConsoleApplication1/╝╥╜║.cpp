#include<iostream>
#include<crtdbg.h>
#include"Character.h"
using namespace std;
void main()
{
	_CrtSetDbgFlag(_CRTDBG_LEAK_CHECK_DF | _CRTDBG_ALLOC_MEM_DF);
	//_crtBreakAlloc = ���� �ѹ�;
	Character ct;
}
